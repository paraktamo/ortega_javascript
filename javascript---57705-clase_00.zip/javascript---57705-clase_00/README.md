<p align="center"> 
    <img src="https://jobs.coderhouse.com/assets/logos_coderhouse.png" alt="CoderHouse"  height="100"/>
</p>

# Bienvenidos a la Comisión #57705

<p align="center"> 
<a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"> 
<img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="Javascript" width="100" height="100"/></a> 
 <a href="https://www.w3.org/html/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="100" height="100"/></a> <a href="https://www.w3schools.com/css/" target="_blank"> 
 <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="100" height="100"/></a> 
</p>

---

## Temas Incluidos

### 1er Fase con Entrega

```ssh
 1. Conceptos generales: Sintaxis y variables

 2. Control de flujos

 3. Ciclos e iteraciones

 4. Funciones
```

### 2da Fase con Entrega

```ssh
 5. Objetos

 6. Arrays

 7. Funciones de orden superior

 8. DOM
```

### 3er Fase con Entrega

```ssh
 9. Eventos

 10. Storage & JSON

 11. Workshop

 12. Operadores avanzados
```

### 4ta Fase

```ssh
 13. Librerías

 14. Asincronía y promesas

 15. Ajax & Fetch

 16. Frameworks & NodeJS
```

## Entrega Final:

### El Proyecto Integrador debe incluir todos los temas vistos en el Curso.

---

## Profesor: Alejandro Daniel Di Stefano
